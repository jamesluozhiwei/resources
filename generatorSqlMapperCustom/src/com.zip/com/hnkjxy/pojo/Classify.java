package com.hnkjxy.pojo;

public class Classify {
    private Integer classifyId;

    private String cllassifyName;

    public Integer getClassifyId() {
        return classifyId;
    }

    public void setClassifyId(Integer classifyId) {
        this.classifyId = classifyId;
    }

    public String getCllassifyName() {
        return cllassifyName;
    }

    public void setCllassifyName(String cllassifyName) {
        this.cllassifyName = cllassifyName == null ? null : cllassifyName.trim();
    }
}